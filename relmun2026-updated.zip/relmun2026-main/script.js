const committeeData = {

  unsc: {
    code: "UNSC",
    number: "01",

    title:
      "UNITED NATIONS<br>SECURITY COUNCIL",

    description:
      "The Security Council is the United Nations' principal body for addressing international peace and security. Delegates will engage in high-level diplomacy, negotiation and decision-making.",

    agenda:
      "TO BE ANNOUNCED"
  },


  unhrc: {
    code: "UNHRC",
    number: "02",

    title:
      "UNITED NATIONS<br>HUMAN RIGHTS COUNCIL",

    description:
      "The Human Rights Council addresses international human rights situations and promotes cooperation, dialogue and policy-focused multilateral action.",

    agenda:
      "TO BE ANNOUNCED"
  },


  unodc: {
    code: "UNODC",
    number: "03",

    title:
      "UNITED NATIONS OFFICE<br>ON DRUGS AND CRIME",

    description:
      "The United Nations Office on Drugs and Crime works around international cooperation against drugs, organised crime, corruption and related transnational challenges.",

    agenda:
      "TO BE ANNOUNCED"
  },


  aippm: {
    code: "AIPPM",
    number: "04",

    title:
      "ALL INDIA<br>POLITICAL PARTIES MEET",

    description:
      "AIPPM brings together representatives of India's political parties to engage in parliamentary debate, political negotiation and deliberation on matters of national importance.",

    agenda:
      "TO BE ANNOUNCED"
  },


  ipla: {
    code: "IPLA",
    number: "05",

    title:
      "INDIAN PREMIER<br>LEAGUE AUCTION",

    description:
      "The Indian Premier League Auction places participants in a high-pressure auction environment involving strategic bidding, team management, financial decisions and competition.",

    agenda:
      "TO BE ANNOUNCED"
  },


  unw: {
    code: "UNW",
    number: "06",

    title:
      "UN WOMEN",

    description:
      "UN Women focuses on gender equality and the empowerment of women and girls, bringing delegates together to discuss international challenges, policy responses and practical action.",

    agenda:
      "TO BE ANNOUNCED"
  }

};



function renderCommitteePage() {

  const target =
    document.getElementById("committeePage");

  if (!target) return;


  const params =
    new URLSearchParams(window.location.search);


  const key =
    params.get("committee") || "unsc";


  const data =
    committeeData[key] || committeeData.unsc;


  document.title =
    `${data.code} | RELMUN '26`;


  target.innerHTML = `

    <section class="committee-detail-hero">

      <div class="detail-number">
        ${data.number}
      </div>


      <div class="section-index">
        COMMITTEE / ${data.code}
      </div>


      <h1>
        ${data.title}
      </h1>


      <p>
        ${data.description}
      </p>


      <div class="detail-meta">

        <span>
          COMMITTEE:
          <strong>${data.code}</strong>
        </span>

        <span>
          FORMAT:
          <strong>ONLINE</strong>
        </span>

        <span>
          DATE:
          <strong>26–27 DECEMBER 2026</strong>
        </span>

      </div>


      <div class="hero-actions">

        <button class="btn btn-gold js-register">
          REGISTER NOW <span>↗</span>
        </button>


        <a
          class="btn btn-outline"
          href="committees.html"
        >
          ALL COMMITTEES <span>→</span>
        </a>

      </div>

    </section>



    <section class="detail-section">

      <div class="section-index">
        01 / AGENDA
      </div>


      <div class="agenda-row">

        <span>
          AGENDA 01
        </span>

        <h2>
          ${data.agenda}
        </h2>

      </div>

    </section>



    <section class="detail-section">

      <div class="section-index">
        02 / BACKGROUND GUIDE
      </div>


      <div class="guide-row">

        <div>

          <small>
            OFFICIAL DOCUMENT
          </small>

          <h2>
            BACKGROUND GUIDE
          </h2>

          <p>
            The official ${data.code} Background Guide
            will be published once the committee's academic
            material has been finalised.
          </p>

        </div>


        <span class="coming">
          COMING SOON
        </span>

      </div>

    </section>



    <section class="detail-section">

      <div class="section-index">
        03 / EXECUTIVE BOARD
      </div>


      <div class="detail-eb">


        <div class="eb-role">

          <small>
            CHAIR
          </small>

          <strong>
            TO BE ANNOUNCED
          </strong>

        </div>


        <div class="eb-role">

          <small>
            VICE CHAIR
          </small>

          <strong>
            TO BE ANNOUNCED
          </strong>

        </div>


        <div class="eb-role">

          <small>
            MODERATOR
          </small>

          <strong>
            TO BE ANNOUNCED
          </strong>

        </div>


      </div>

    </section>



    <section class="detail-cta">

      <p class="eyebrow">
        READY?
      </p>


      <h2>
        ENTER THE<br>
        <em>COMMITTEE.</em>
      </h2>


      <p>
        Choose your preferred registration platform
        to register for ${data.code}.
      </p>


      <button class="btn btn-gold big js-register">
        REGISTER NOW <span>↗</span>
      </button>

    </section>

  `;


  bindRegistration();

}



function bindRegistration() {

  const modal =
    document.getElementById("registrationModal");

  if (!modal) return;


  document
    .querySelectorAll(".js-register")
    .forEach(button => {

      button.onclick = () => {

        modal.classList.add("open");

        modal.setAttribute(
          "aria-hidden",
          "false"
        );

        document.body.classList.add(
          "modal-open"
        );

      };

    });


  document
    .querySelectorAll(".js-close-modal")
    .forEach(button => {

      button.onclick = () => {

        modal.classList.remove("open");

        modal.setAttribute(
          "aria-hidden",
          "true"
        );

        document.body.classList.remove(
          "modal-open"
        );

      };

    });

}



function setupMenu() {

  const toggle =
    document.querySelector(".menu-toggle");

  const nav =
    document.querySelector(".nav-links");


  if (!toggle || !nav) return;


  toggle.addEventListener(
    "click",
    () => {

      const open =
        nav.classList.toggle("open");


      toggle.setAttribute(
        "aria-expanded",
        String(open)
      );

    }
  );


  nav
    .querySelectorAll("a")
    .forEach(link => {

      link.addEventListener(
        "click",
        () => {

          nav.classList.remove("open");

        }
      );

    });

}



document.addEventListener(
  "DOMContentLoaded",
  () => {

    renderCommitteePage();

    bindRegistration();

    setupMenu();
    setupChatbot();


    document.addEventListener(
      "keydown",
      e => {

        if (e.key === "Escape") {

          document
            .querySelectorAll(".modal.open")
            .forEach(modal => {

              modal.classList.remove(
                "open"
              );

              modal.setAttribute(
                "aria-hidden",
                "true"
              );

              document.body.classList.remove(
                "modal-open"
              );

            });

        }

      }
    );

  }
);
\n\n/* =========================\n   RELMUN CHATBOT\n   ========================= */\n\nfunction setupChatbot() {\n  const toggle = document.getElementById("chatbotToggle");\n  const panel = document.getElementById("chatbotPanel");\n  const close = document.getElementById("chatbotClose");\n  const form = document.getElementById("chatbotForm");\n  const input = document.getElementById("chatbotInput");\n  const messages = document.getElementById("chatbotMessages");\n  const suggestions = document.getElementById("chatbotSuggestions");\n\n  if (!toggle || !panel || !form || !input || !messages) return;\n\n  function openChat() {\n    panel.classList.add("open");\n    panel.setAttribute("aria-hidden", "false");\n    toggle.setAttribute("aria-expanded", "true");\n    if (!messages.children.length) addMessage("bot", "Hi! I'm the RELMUN '26 assistant. Ask me about the conference, committees, registration, or the organising team.");\n    setTimeout(() => input.focus(), 100);\n  }\n\n  function closeChat() {\n    panel.classList.remove("open");\n    panel.setAttribute("aria-hidden", "true");\n    toggle.setAttribute("aria-expanded", "false");\n  }\n\n  function addMessage(type, text) {\n    const bubble = document.createElement("div");\n    bubble.className = `chat-message ${type}`;\n    bubble.textContent = text;\n    messages.appendChild(bubble);\n    messages.scrollTop = messages.scrollHeight;\n  }\n\n  function getAnswer(question) {\n    const q = question.toLowerCase().trim();\n\n    if (/when|date|dates|day|days|schedule/.test(q)) {\n      return "RELMUN '26 takes place on 26–27 December 2026. The conference is online via Google Meet, and all times are in IST.";\n    }\n    if (/register|registration|sign up|signup|apply/.test(q)) {\n      return "Delegate registration opens on 1 October 2026. You can register through MyMUN or Gavelling using the Register button on the website.";\n    }\n    if (/free|fee|cost|price|paid/.test(q)) {\n      return "RELMUN '26 is a free online conference, so delegate registration has no conference fee.";\n    }\n    if (/committee|committees|unsc|unhrc|unodc|aippm|ipla|ipl|unw|women/.test(q)) {\n      return "RELMUN '26 currently has six committees: UNSC, UNHRC, UNODC, AIPPM, IPL Auction (IPLA), and UN Women (UNW). Visit the Committees page for details.";\n    }\n    if (/un women|unw|women/.test(q)) {\n      return "UN Women (UNW) is one of RELMUN '26's committees, focusing on gender equality and the empowerment of women and girls. Its agenda will be announced.";\n    }\n    if (/team|organis|organizing|organising|chief advisor|aashi|madhav|delegate affairs/.test(q)) {\n      return "The organising team includes Secretary-General Akshith Kabilan, Deputy Secretary-General S. Shreyaas, Director-General Laasya Vikram, Head of Administration & Outreach Abimayur R, Chief Advisor Aashi K, and USG · Delegate Affairs Madhav Bhardwaj.";\n    }\n    if (/eb|executive board|chair|vice chair|moderator/.test(q)) {\n      return "Executive Board details are announced committee-by-committee. Check the EB section of the website for the latest updates.";\n    }\n    if (/online|google meet|format|where|venue/.test(q)) {\n      return "RELMUN '26 is entirely online and will be conducted via Google Meet.";\n    }\n    if (/about|what is relmun|relmun/.test(q)) {\n      return "RELMUN '26 is a two-day online Model United Nations conference built around Relations, Engagement and Leadership, taking place on 26–27 December 2026.";\n    }\n    if (/contact|help|email|reach/.test(q)) {\n      return "For conference-related queries, use the contact details provided on the RELMUN website or message the organising team through the official community.";\n    }\n\n    return "I can help with RELMUN '26 dates, registration, committees, UN Women, the organising team, EB information, and the online format. Try asking one of those.";\n  }\n\n  function ask(question) {\n    const clean = question.trim();\n    if (!clean) return;\n    addMessage("user", clean);\n    input.value = "";\n    setTimeout(() => addMessage("bot", getAnswer(clean)), 180);\n  }\n\n  toggle.addEventListener("click", () => {\n    if (panel.classList.contains("open")) closeChat();\n    else openChat();\n  });\n  if (close) close.addEventListener("click", closeChat);\n  form.addEventListener("submit", e => {\n    e.preventDefault();\n    ask(input.value);\n  });\n  if (suggestions) {\n    suggestions.querySelectorAll("button").forEach(button => {\n      button.addEventListener("click", () => ask(button.dataset.question || button.textContent));\n    });\n  }\n}\n